package com.nucleus.service.user;

import com.nucleus.dao.user.UserDAO;
import com.nucleus.dao.user.UserDAOFactory;
import com.nucleus.model.domain.User;

public class UserServiceImp implements UserService {
	UserDAO dao = UserDAOFactory.getObject("rdbms");
	@Override
	public User getUser(String uName, String uPsw) {
		if(dao.validateUser(uName,uPsw))
			return dao.getUser(uName);
		else
			return null;
	}

}
