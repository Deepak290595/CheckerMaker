package com.nucleus.connection;



public class ConnectionFactory {
	private ConnectionFactory(){}
	public static ConnectionSetup getConnection(String connectionType){
		if(connectionType.equals("oracle"))
			return new OracleConnection();
		else if(connectionType.equals("mysql"))
			return new MySQLConnection();
		else
			return null;
		
	}
}
