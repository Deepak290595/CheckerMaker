package com.nucleus.service.user;

import com.nucleus.model.domain.User;

public interface UserService {
	public User getUser(String uName,String uPsw);
}
