package com.nucleus.model.domain;

import java.io.Serializable;

public class User implements Serializable{
	private String uID;
	private String uName;
	private String role;
	public String getuID() {
		return uID;
	}
	public void setuID(String uID) {
		this.uID = uID;
	}
	public String getuName() {
		return uName;
	}
	public void setuName(String uName) {
		this.uName = uName;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	
	public User(String uID, String uName, String role) {
		this.uID = uID;
		this.uName = uName;
		this.role = role;
	}
	@Override
	public String toString() {
		return "User [uID=" + uID + ", uName=" + uName +/* ", password="
				+ password + */", role=" + role + "]";
	}
	
}
