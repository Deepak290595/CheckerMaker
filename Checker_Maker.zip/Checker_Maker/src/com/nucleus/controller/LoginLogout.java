package com.nucleus.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.nucleus.service.user.UserService;
import com.nucleus.service.user.UserServiceImp;

/**
 * Servlet implementation class Login_Logout
 */
@WebServlet("/Login_Logout")
public class LoginLogout extends HttpServlet {
	private static final long serialVersionUID = 1L;
    UserService service;
    HttpSession session;
    public LoginLogout() {
        super();
    }
    private void login(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
    	response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		String uName = request.getParameter("id");
		String uPsw = request.getParameter("password");
		service= new UserServiceImp();
		if(service.getUser(uName, uPsw)==null){
			out.println("<script type=\"text/javascript\">");
	     	out.println("alert('Username Password Missmatch');");
	     	out.println("location='LoginPage.jsp';");
	     	out.println("</script>");
		}
		else if(service.getUser(uName, uPsw).getRole().equals("maker")){
			session = request.getSession();
			session.setAttribute("UserName", service.getUser(uName, uPsw).getuName());
			RequestDispatcher dispatcher = request.getRequestDispatcher("/MakerHome.jsp");
			dispatcher.forward(request, response);
			}
		else if(service.getUser(uName, uPsw).getRole().equals("checker") )
		{
			RequestDispatcher dispatcher = request.getRequestDispatcher("/CheckerHome.jsp");
			dispatcher.forward(request, response);
		}
			
		
	}
    private void logout(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
    	
		RequestDispatcher dispatcher = request.getRequestDispatcher("/LogOut.jsp");
		dispatcher.forward(request, response);
		
	}
    @Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			logout(request,response);
	}
    @Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String type = request.getParameter("type");
		if(type.equals("login"))
			login(request,response);
		else
			logout(request,response);
	}

}
