package com.nucleus.service.customer;

import java.util.ArrayList;
import java.util.List;

import com.nucleus.dao.customer.CustomerDAO;
import com.nucleus.dao.customer.CustomerDAOFactory;
import com.nucleus.model.domain.Customer;

public class CustomerServiceImp implements CustomerService {
	CustomerDAO dao = CustomerDAOFactory.getObject("rdbms");
	List<Customer> customerList = new ArrayList<>();
	@Override
	public boolean save(Customer customer) {
		if(!dao.save(customer))
			return false;
		else
			return true;
	}

	@Override
	public List<Customer> view(String code) {
		customerList = dao.view(code);
		return customerList;
	}

	@Override
	public List<Customer> viewAll() {
		customerList = dao.viewAll();
		return customerList;
	}

	@Override
	public boolean delete(String code) {
		if(dao.delete(code))
			return true;
		else
			return false;
		
	}

	@Override
	public Customer update1(String code) {
		try{
		return dao.view(code).get(0);
		}
		catch(Exception e){
			return null;
		}
	}
	@Override
	public boolean update2(Customer customer) {
		
		if(dao.update(customer))
			return true;
		else
			return false;
	}

}
